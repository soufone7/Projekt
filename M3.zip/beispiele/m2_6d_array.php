<?php
/**
 * Praktikum DBWT. Autoren:
 * Zakaria, El Yamani, 3737198
 * Soufiane, Ait lahssaine, 3730375
 */

$famousMeals = [
    1 => ['name' => 'Currywurst mit Pommes',
        'winner' => [2001, 2003, 2007, 2010, 2020]],
    2 => ['name' => 'Hähnchencrossies mit Paprikareis',
        'winner' => [2002, 2004, 2008]],
    3 => ['name' => 'Spaghetti Bolognese',
        'winner' => [2011, 2012, 2017]],
    4 => ['name' => 'Jägerschnitzel mit Pommes',
        'winner' => 2019]
]; ?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Array</title>

</head>
<body>
<h2>Gewinnergerichte</h2>
<ol>
    <?php foreach ($famousMeals as $meal) {
        echo "<li>";

        echo $meal['name'] . "<br>";

        $years = [];

        if (!is_array($meal['winner'])) {
            $years[] = $meal['winner'];
        }

        if (is_array($meal['winner'])) {
            foreach ($meal['winner'] as $y) {
                $years[] = $y;
            }
        }

        rsort($years);

        echo implode(", ", $years);

        echo "</li>";
    }
    ?>
</ol>

<hr>

<?php
// finde Jahre ohne Gewinner
function JahreOhneGewinner($meals, $start, $ende) {
	$alleGewinner = [];

	// Alle Gewinnerjahre sammeln
	foreach ($meals as $meal) { // Jedes Gericht/Objekt im Array durchlaufen
		if (is_array($meal['winner'])) { // Falls 'winner' mehrere Jahre enthält (Array?)
			$alleGewinner = array_merge($alleGewinner, $meal['winner']);
		} else {
			$alleGewinner[] = $meal['winner']; // Einzelnes Gewinnerjahr anhängen
		}
	}

	$jahreOhne = [];
	for ($jahr = $start; $jahr <= $ende; $jahr++) {
		if (!in_array($jahr, $alleGewinner)) { // Jahr NICHT in Gewinnerliste?
			$jahreOhne[] = $jahr; // Dann Jahr hinzufügen
		}
	}
	return $jahreOhne;
}

$fehlende = JahreOhneGewinner($famousMeals, 2000, date('Y'));

echo "<h3>Jahre ohne Gewinner:</h3>";
echo implode(", ", $fehlende);
?>

</body>
</html>