<?php
/**
 * Praktikum DBWT. Autoren:
 * Zakaria, El Yamani, 3737198
 * Soufiane, Ait lahssaine, 3730375
 */

include 'm2_6a_standardparameter.php';

echo "<h2>include</h2>";

echo "addieren(10, 5) = " . addieren(10, 5) . "<br>";
echo "addieren(4) = " . addieren(4) . "<br>";
