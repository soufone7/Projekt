<?php
/**
 * Praktikum DBWT. Autoren:
 * Zakaria, El Yamani, 3737198
 * Soufiane, Ait lahssaine, 3730375
 */

echo "<h2>a) str_replace</h2>";
$text = "Willkommen in der Mensa! Die Mensa ist toll.";
//str_replace($search, $replace, $subject) – Ersetzt alle Vorkommen von $search durch $replace in $subject (optional: $count).
$ersetzt = str_replace("Mensa", "E-Mensa", $text);
echo $text;
echo "<br>";
echo $ersetzt;

echo "<h2>b) str_repeat</h2>";
//str_repeat(string $string, int $times) – Wiederholt $string $times-mal und gibt den zusammengefügten String zurück.
$Wiederholen = str_repeat("_", 30);
echo $Wiederholen;

echo "<h2>c) substr</h2>";

$teilstring = "Informatik";
//substr(string $string, int $offset, ?int $length = null) – Gibt Teilstring ab $offset (negativ = von hinten), optional begrenzt durch $length.
$teilstring_erste_9 = substr($teilstring, 0, 9);
$teilstring_ab_10 = substr($teilstring, 10);
$teilstring_letzte_4 = substr($teilstring, -4);
echo "<pre> String: $teilstring
                substr(\$teilstring, 0, 9)  -> $teilstring_erste_9
                substr(\$teilstring, 10)    -> $teilstring_ab_10
                substr(\$teilstring, -4)    -> $teilstring_letzte_4 </pre>";


// Ränder säubern
echo "<h2>d) trim / ltrim / rtrim</h2>";
$text = "     Currywurst    ";
$trim_all = trim($text);              // entfernt Whitespace links & rechts
$l_only   = ltrim($text);             // entfernt links
$r_only   = rtrim($text);             // entfernt rechts
echo "<pre>Text:        -> " . str_replace(["\t","\n"," "], ["\\t","\\n","·"], $text) . "
trim()       -> " . str_replace(["\t","\n"," "], ["\\t","\\n","·"], $trim_all) . "
ltrim()      -> " . str_replace(["\t","\n"," "], ["\\t","\\n","·"], $l_only) . "
rtrim()      -> " . str_replace(["\t","\n"," "], ["\\t","\\n","·"], $r_only) . " </pre>";

echo "<h2>e) String-Konkatentation (Aneinanderhängen von Zeichenketten)</h2>";
//In PHP macht man das mit dem Punkt (.) — nicht mit dem Pluszeichen wie in vielen anderen Sprachen.
$gericht = "Jägerschnitzel";
$beilage = "mit Pommes";
$preis   = 6.2;

// 1) Mit Punkt verbinden:
$beschreibung = $gericht . " " . $beilage . " – " . number_format($preis, 2, ",", "") . "€";
echo "<pre>$beschreibung</pre>";

// 2) Mit .= anhängen:
$zeile = "Heute: ";
$zeile .= $gericht;
$zeile .= " | ";
$zeile .= $beilage;
echo "<pre>$zeile</pre>";


