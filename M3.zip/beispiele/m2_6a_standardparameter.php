<?php
/**
 * Praktikum DBWT. Autoren:
 * Zakaria, El Yamani, 3737198
 * Soufiane, Ait lahssaine, 3730375
 */
function addieren($a, $b = 0){
    return $a + $b;
}

echo "<h2>Standardparameter</h2>";
echo "addieren(5,3) = " . addieren (5, 3) . "<br>";
echo "addieren(7) = " . addieren(7) . "<br>";


