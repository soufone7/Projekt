<?php
/**
 * Praktikum DBWT. Autoren:
 * Zakaria, El Yamani, 3737198
 * Soufiane, Ait lahssaine, 3730375
 */

const GET_PARAM_MIN_STARS = 'search_min_stars';
const GET_PARAM_SEARCH_TEXT = 'search_text';
const GET_PARAM_SHOW_DESC   = 'show_description';   // (e) neuer GET-Parameter
const GET_PARAM_LANG         = 'sprache';          // (g)
const GET_PARAM_TOPFLOP = 'topflop';

// --- (g) statische Texte in DE/EN ---
$T = [
        'de' => [
                'meal' => 'Gericht',
                'desc' => 'Beschreibung anzeigen: ',
                'allergens' => 'Allergene',
                'ratings' => 'Bewertungen',
                'avg' => 'Durchschnitt',
                'filter_text' => 'Filter (Text):',
                'filter_stars' => 'min. Sterne:',
                'show_desc' => 'Beschreibung anzeigen:',
                'yes' => 'Ja', 'no' => 'Nein',
                'author' => 'Autor/in',
                'text' => 'Text', 'stars' => 'Sterne',
                'search' => 'Suchen',
                'lang' => 'Sprache',
                'intern' => 'Preis intern',
                'extern' => 'Preis extern',
                'top' => 'TOP', 'flopp' => 'FLOPP',
                'name' => 'Süßkartoffeltaschen mit Frischkäse und Kräutern gefüllt',
                'description' => 'Die Süßkartoffeln werden vorsichtig aufgeschnitten und der Frischkäse eingefüllt.'
        ],
        'en' => [
                'meal' => 'Meal',
                'desc' => 'Show description: ',
                'allergens' => 'Allergens',
                'ratings' => 'Ratings',
                'avg' => 'Average',
                'filter_text' => 'Filter (text):',
                'filter_stars' => 'min. stars:',
                'show_desc' => 'Show description:',
                'yes' => 'Yes', 'no' => 'No',
                'author' => 'Author',
                'text' => 'Text', 'stars' => 'Stars',
                'search' => 'Search',
                'lang' => 'Language',
                'intern' => 'Price internal',
                'extern' => 'Price external',
                'top' => 'TOP', 'flopp' => 'FLOPP',
                'name'=> 'Sweet Potato Pockets Filled with Cream Cheese and Herbs',
                'description' => 'The sweet potatoes are carefully cut open and filled with cream cheese',
        ]
];
$lang = (isset($_GET[GET_PARAM_LANG]) && $_GET[GET_PARAM_LANG] === 'en') ? 'en' : 'de';
$L = $T[$lang];

/**
 * List of all allergens.
 */
$allergens = [
    11 => 'Gluten',
    12 => 'Krebstiere',
    13 => 'Eier',
    14 => 'Fisch',
    17 => 'Milch'
];

$meal = [
    'name' => 'Süßkartoffeltaschen mit Frischkäse und Kräutern gefüllt',
    'description' => 'Die Süßkartoffeln werden vorsichtig aufgeschnitten und der Frischkäse eingefüllt.',
    'price_intern' => 2.90,
    'price_extern' => 3.90,
    'allergens' => [11, 13],
        'amount' => 42             // Number of available meals
    ];

$ratings = [
    [   'text' => 'Die Kartoffel ist einfach klasse. Nur die Fischstäbchen schmecken nach Käse. ',
        'author' => 'Ute U.',
        'stars' => 2 ],
    [   'text' => 'Sehr gut. Immer wieder gerne',
        'author' => 'Gustav G.',
        'stars' => 4 ],
    [   'text' => 'Der Klassiker für den Wochenstart. Frisch wie immer',
        'author' => 'Renate R.',
        'stars' => 4 ],
    [   'text' => 'Kartoffel ist gut. Das Grüne ist mir suspekt.',
        'author' => 'Marta M.',
        'stars' => 3 ]
];

/* Eingaben lesen (f) Suchfeld nach Submit beibehalten */
$searchTerm = isset($_GET[GET_PARAM_SEARCH_TEXT]) ? (string)$_GET[GET_PARAM_SEARCH_TEXT] : '';
$minStars   = isset($_GET[GET_PARAM_MIN_STARS])   ? (int)$_GET[GET_PARAM_MIN_STARS]     : null;
/* (e) Beschreibung standardmäßig zeigen; bei show_description=0 ausblenden */
$showDescription = !isset($_GET[GET_PARAM_SHOW_DESC]) || $_GET[GET_PARAM_SHOW_DESC] !== '0';
/* Bewertungen sortieren (i) */
$topflop = isset($_GET[GET_PARAM_TOPFLOP]) ? $_GET[GET_PARAM_TOPFLOP] : null;

$showRatings = [];

if ($searchTerm !== '') {
    foreach ($ratings as $rating) {
        if (stripos($rating['text'], $searchTerm) !== false) {
            $showRatings[] = $rating;
        }
    }
} elseif ($topflop === 'top' || $topflop === 'flopp') {
    // (i) nur höchste oder niedrigste Bewertungen zeigen
    if (!empty($ratings)) {
        $stars = array_column($ratings, 'stars');
        $target = ($topflop === 'top') ? max($stars) : min($stars);
        foreach ($ratings as $rating) {
            if ($rating['stars'] === $target) {
                $showRatings[] = $rating;
            }
        }
    }
} elseif ($minStars !== null && $minStars !== 0) {
    foreach ($ratings as $rating) {
        if ($rating['stars'] >= $minStars) {
            $showRatings[] = $rating;
        }
    }
} else {
    $showRatings = $ratings;
}
/* (d) Korrigierte Durchschnittsberechnung */
function calcMeanStars(array $ratings): float {                                   // (d)
    $c = count($ratings); if ($c===0) return 0.0;
    $s = 0.0; foreach($ratings as $r){ $s += (float)$r['stars']; } return $s/$c;
}

// g) URL mit geänderten/zusätzlichen Parametern bauen (für Sprachlinks)
function url_with(array $kv): string {
    $q = array_merge($_GET, $kv); return '?' . http_build_query($q);
}

// (h) Preise schön formatiert mit 2 Nachkommastellen und €-Zeichen
function formatEuro(float $preis): string {
    return number_format($preis, 2, ',', '') . ' €';
}
// j Stern
function num_eur(float $n): string { return number_format($n, 2, ',', '') . '€'; } // (h)
function renderStars(int $n, int $max=5): string {                               // (j)
    $n = max(0, min($n, $max));
    return str_repeat('★', $n) . str_repeat('☆', $max-$n);
}

?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8"/>
    <title>Gericht: <?php echo $meal['name']; ?></title>
    <style>
        * {
            font-family: Arial, serif;
        }
        thead{
            font-weight: bold;
        }
        .rating {
            color: darkslategray;
        }
        td, th {
            padding: .3rem .5rem; border-bottom: 1px solid #ddd; }
    </style>
</head>
<body>
    <!-- (g) statische Texte in DE/EN -->
    <p class="lang">
        <?php echo htmlspecialchars($L['lang']); ?>:
        <a href="<?php echo url_with([GET_PARAM_LANG=>'de']); ?>">DE</a>
        <a href="<?php echo url_with([GET_PARAM_LANG=>'en']); ?>">EN</a>
    </p>

    <h1><?php echo htmlspecialchars($L['meal'].': '.$L['name']); ?></h1>
    <!-- (e) show_description steuern -->
    <p><?php if( $showDescription==1) : ?>
    <p><strong><?php echo htmlspecialchars($L['description']); ?></strong>
       </p>
    <?php endif; ?>

    <!-- (b) Allergene als ungeordnete Liste -->
    <?php if (!empty($meal['allergens'])): ?>
        <h3><?php echo htmlspecialchars($L['allergens']); ?></h3>
        <ul>
            <?php foreach ($meal['allergens'] as $all_num): ?>
                <li><?php echo $allergens[$all_num] ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <p>
        <strong><?php echo htmlspecialchars($L['intern']); ?>:</strong>
        <?php echo formatEuro($meal['price_intern']); ?>
        &nbsp; | &nbsp;
        <strong><?php echo htmlspecialchars($L['extern']); ?>:</strong>
        <?php echo formatEuro($meal['price_extern']); ?>
    </p>

    <h1><?php echo htmlspecialchars($L['ratings'].': '.$L['avg']); ?>: ( <?php echo number_format(calcMeanStars($ratings), 2, ',', '.'); ?>)</h1>
    <form method="get">
        <!--  (i) nur höchste oder niedrigste Bewertungen zeigen-->
        <label for="topflop">Bewertungen:</label>
        <select id="topflop" name="topflop">
            <option value="">-- alle --</option>
            <option value="top" <?php echo ($topflop === 'top') ? 'selected' : ''; ?>>TOP</option>
            <option value="flopp" <?php echo ($topflop === 'flopp') ? 'selected' : ''; ?>>FLOPP</option>
        </select>

        <label for="search_text">Filter:</label>
        <!-- (f) Wert beibehalten -->
        <input id="search_text" type="text" name="search_text" placeholder="Text"
        value="<?php echo htmlspecialchars($searchTerm); ?>">

        <!-- optional: Sterne-Filter anzeigen -->
        <label for="number">Filter:</label>
        <input type="number" name="search_min_stars" min="1" max="5" step="1" placeholder=<?php echo htmlspecialchars($L['stars']); ?>>

        <!-- (e) show_description steuern -->
        <label for="show_description"><?php echo htmlspecialchars($L['desc']); ?></label>
        <select id="show_description" name="show_description">
            <option value="1" <?php echo $showDescription ? 'selected' : '' ?>><?php echo htmlspecialchars($L['yes']); ?></option>
            <option value="0" <?php echo !$showDescription ? 'selected' : '' ?>><?php echo htmlspecialchars($L['no']); ?></option>
        </select>

        <input type="submit" value="<?php echo htmlspecialchars($L['search']); ?>">

    </form>
        <table class="rating">
        <thead>
        <tr>
            <th><?php echo htmlspecialchars($L['text']); ?></th>
            <th><?php echo htmlspecialchars($L['author']); ?></th>
            <th><?php echo htmlspecialchars($L['stars']); ?></th>
        </tr>
        </thead>
            <tbody>
            <?php foreach ($showRatings as $rating): ?>
                <tr>
                    <td class="rating_author"><?php echo htmlspecialchars($rating['author']); ?></td>
                    <td class="rating_text"><?php echo htmlspecialchars($rating['text']); ?></td>
                    <td class="rating_stars"><?php echo renderStars((int)$rating['stars']); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
</body>
</html>