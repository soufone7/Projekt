<?php
/**
 * Praktikum DBWT. Autoren:
 * Zakaria, El Yamani, 3737198
 * Soufiane, Ait lahssaine, 3730375
 */

$ergebnis = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") { // Prüft: Request-Methode ist POST (Formular gesendet)
    $b = $_POST["b"];  //erkannt mithilfe von name
    $a = $_POST["a"]; // $_POST: Form-Daten (Feld "a")


    if (isset($_POST["addieren"])){ // isset(): Feld existiert → Addieren gewählt (z.B. Submit-Button)
        $ergebnis = $a + $b;
    }

    if (isset($_POST["multiplizieren"])){
        $ergebnis = $a * $b;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Rechner</title>
</head>
<body>
  <h2>Einfacher Rechner</h2>

  <form method="post">
    <label>Zahl a:</label>
    <input type="text" name="a"><br><br>

    <label>Zahl b:</label>
    <input type="text" name="b"><br><br>

    <button type="submit" name="addieren">addieren</button>
    <button type="submit" name="multiplizieren">multiplizieren</button>
  </form>

  <?php
  if ($ergebnis !== "") {
    echo "<h3>Ergebnis: $ergebnis</h3>";
  }
  ?>
</body>
</html>


<!-- Hinweise:
 $_SERVER["REQUEST_METHOD"] – liefert HTTP-Methode (GET/POST/...)
 "POST" – Daten im Request-Body (nicht in URL), für Formulareingaben
 $_POST – Array aller POST-Felder nach Name
 isset(x) – true, wenn Variable/Array-Key existiert und nicht null*/ -->