
<?php
/**
 * Praktikum DBWT. Autoren:
 * Zakaria, El Yamani, 3737198
 * Soufiane, Ait lahssaine, 3730375
 */

$ip = $_SERVER['REMOTE_ADDR'];        // IP des Clients
$browser = $_SERVER['HTTP_USER_AGENT'];    // Browser-Info
$timestamp = date("Y-m-d H:i:s");            // aktuelles Datum + Zeit

$zeile = "$timestamp | $ip | $browser" . PHP_EOL;

//Schreibt $zeile in die Datei; mit FILE_APPEND wird ans Ende angehängt (Datei wird falls nötig erstellt).
file_put_contents("accesslog.txt", $zeile, FILE_APPEND);

echo "<h3>Eintrag gespeichert!</h3>";
echo "<p>$zeile</p>";
