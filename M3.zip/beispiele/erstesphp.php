<?php
/**
 * Praktikum DBWT. Autoren:
 * Zakaria, El Yamani, 3737198
 * Soufiane, Ait lahssaine, 3730375
 */

echo "Erstes PHP-Skript <br>";
phpinfo();