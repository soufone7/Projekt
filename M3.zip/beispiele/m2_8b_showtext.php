<?php
/**
 * Praktikum DBWT. Autoren:
 * Zakaria, El Yamani, 3737198
 * Soufiane, Ait lahssaine, 3730375
 */
// Kleine Hilfsfunktion:
// Wandelt Sonderzeichen um, damit nichts kaputt angezeigt wird.
// Schützt vor HTML-Problemen im Browser.
function e($s) {
    // ENT_QUOTES: ' und " escapen; ENT_SUBSTITUTE: ungültige Bytes durch Ersatzzeichen
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// Prüfen ob der Nutzer ein Suchwort über GET übergeben hat
if (isset($_GET['suche'])) {

    // Suchwort auslesen und überflüssige Leerzeichen entfernen
    $suchwort = trim($_GET['suche']);
    $gefunden = false;

    // Datei Zeile für Zeile laden
    // FILE_IGNORE_NEW_LINES: entfernt Zeilenumbrüche
    // FILE_SKIP_EMPTY_LINES: leere Zeilen werden übersprungen
    $zeilen = file("en.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Jede Zeile der Datei durchgehen6

    foreach ($zeilen as $zeile) {

        // Jede Zeile im Format: Deutsch;Englisch
        // explode trennt die Zeile beim ersten Semikolon
        $teile = explode(";", $zeile, 2);

        // Wenn weniger als 2 Teile existieren, ist die Zeile ungültig
        if (count($teile) < 2) {
            continue;
        }

        // Links = deutsches Wort
        // Rechts = englisches Wort
        $de = trim($teile[0]);
        $en = trim($teile[1]);

        // Vergleich ohne Beachtung der Groß- und Kleinschreibung
        if (strcasecmp($suchwort, $de) === 0) {
            // Ausgabe der Übersetzung: Deutsch → Englisch
            echo "<h3>".e($de)." → ".e($en)."</h3>";
            $gefunden = true;
            break;
        }

        // Vergleich für den Fall, dass das Suchwort Englisch ist
        if (strcasecmp($suchwort, $en) === 0) {
            // Ausgabe der Übersetzung: Englisch → Deutsch
            echo "<h3>".e($en)." → ".e($de)."</h3>";
            $gefunden = true;
            break;
        }
    }

    // Falls das Wort in keiner Zeile vorkommt
    if (!$gefunden) {
        echo "<p>Das gesuchte Wort <b>".e($suchwort)."</b> ist nicht enthalten.</p>";
    }

} else {

    // Wenn kein Suchwort übergeben wurde, Formular anzeigen
    echo '<form method="get">
            <label>Suchwort:</label>
            <input type="text" name="suche">
            <button type="submit">Suchen</button>
          </form>';
}
