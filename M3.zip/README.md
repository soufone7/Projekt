# Praktikum Team 710

**Datenbanken und Webtechnologien WS 2025/2026**

* Nutzen Sie dieses Repository für Ihre Abgaben in den einzelnen Meilensteinen (`M1.zip`, `M2.zip`, etc.). 

* Ihr Team muss die Abgabe korrekt benannt und fristgerecht durchführen, um zur Abnahme zugelassen zu werden.

* Sie dürfen dieses Repository auch für die Entwicklung Ihrer Lösungen benutzen.