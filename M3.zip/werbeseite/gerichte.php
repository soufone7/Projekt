<?php
/**
 * Praktikum DBWT. Autoren:
 * Zakaria, El Yamani, 3737198
 * Soufiane, Ait lahssaine, 3730375

$gerichte = [
    [
        'name' => 'Couscoussalat mit Hähnchen und Tomaten',
        'price_intern' => 3.00,
        'price_extern' => 5.40,
        'img' => 'couscous.jpeg'
    ],
    [
        'name' => 'Spinatrisotto mit kleinen Samosa-Teigäckchen und gemischtem Salat',
        'price_intern' => 2.90,
        'price_extern' => 5.30,
        'img' => 'spinatrisotto.jpeg'
    ],
    [
        'name' => 'Linsencurry mit Kokosmilch und Basmatireis',
        'price_intern' => 2.80,
        'price_extern' => 5.10,
        'img' => 'linsencurry.jpg'
    ],
    [
        'name' => 'Tagin mit Rindfleisch',
        'price_intern' => 2.80,
        'price_extern' => 5.10,
        'img' => 'Tagin.jpeg'
    ],
];*/