<?php

/* 9.1 – Anzahl Gerichte aus DB */
// Verbindung (mysqli) herstellen
$link = mysqli_connect("localhost", "root", "SouF", "emensawerbeseite");
if (!$link) { echo "DB-Fehler: " , mysqli_connect_error(); exit(); }

// COUNT(*) der Tabelle gericht
$sqlGerichte = "SELECT COUNT(*) AS anzahl FROM gericht";
$resGerichte = mysqli_query($link, $sqlGerichte);
if (!$resGerichte) { echo "SQL-Fehler: " , mysqli_error($link) ; exit(); }

// Ergebnis übernehmen
$rowG = mysqli_fetch_assoc($resGerichte);
$gerichte = (int)$rowG['anzahl'];

// Aufräumen (optional)
mysqli_free_result($resGerichte);

/* 9.2 – Anzahl Newsletter-Anmeldungen aus Datei */
$newsletterDatei = __DIR__ . "/data/newsletter.csv"; // eine Anmeldung pro Zeile
$anzNewsletter = 0;

if (is_readable($newsletterDatei)) {
    $anzNewsletter = 0;
    $fh = fopen($newsletterDatei, 'r');
    if ($fh) {
        while (($line = fgets($fh)) !== false) {
            // Leere Zeilen ignorieren
            if (trim($line) !== '') { $anzNewsletter++; }
        }
        fclose($fh);
    }
} else {
    // Datei fehlt? dann 0
    $anzNewsletter = 0;
}

/* 9.3 – PHP: Besuch speichern + Gesamtzahl lesen */
// Verbindung (mysqli) wiederverwenden oder neu öffnen:
if (!isset($link) || $link === false) {
    $link = mysqli_connect("localhost", "root", "1234", "emensawerbeseite");
    if (!$link) { echo "DB-Fehler: " , mysqli_connect_error(); exit(); }
}

/* Besuch speichern (einfacher Zähler: pro Seitenaufruf ein Datensatz) */
$sqlInsert = "INSERT INTO besuch () VALUES ()";
if (!mysqli_query($link, $sqlInsert)) {
    echo "Insert-Fehler: " , mysqli_error($link); exit();
}

/* Gesamtzahl Besuche lesen */
$sqlBesuche = "SELECT COUNT(*) AS anzahl FROM besuch";
$resBesuche = mysqli_query($link, $sqlBesuche);
if (!$resBesuche) { echo "SQL-Fehler: " , mysqli_error($link); exit(); }
$rowB = mysqli_fetch_assoc($resBesuche);
$besucherGesamt = (int)$rowB['anzahl'];
mysqli_free_result($resBesuche);